+# SOEN341
+This porject is a web application for students to choose the courses for software engineering.
We need to let the student to choose the time slots for their classes. These courses are organized into
a cuuriculium with a pre-defined prerequisite structure

## Contributors
# Minhao Yu

