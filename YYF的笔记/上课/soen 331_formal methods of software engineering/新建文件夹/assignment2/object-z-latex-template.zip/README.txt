
File oz.sty contains a collection of macros for typesetting Object-Z.
It must be placed in the same folder as your .tex file.

--